<?php

function teacher_home(){
    header('Location: account/index.php');
}

teacher_home();
