<?php

header('Location: stud_profile.php');