
<style>
	.style{
		background: red;
		text-align: center;
		padding: 23%;
		border-radius: 80px;
		font-size: 200%
	}
</style>

<h4 class="style"> File Not Found! 
		<p> <button onclick="history.go(-1)" class>Back</button> </p>	
</h4>