<?php
function hostels(){
    header('Location: all_hostels.php');
}

hostels();
