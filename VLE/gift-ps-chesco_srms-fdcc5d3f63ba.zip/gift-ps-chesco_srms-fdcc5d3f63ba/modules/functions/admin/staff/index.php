<?php

header('Location: all_staff.php');