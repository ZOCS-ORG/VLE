<?php

    function admin_home(){
        header('Location: account/index.php');
    }

    admin_home();