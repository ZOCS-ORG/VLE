<?php

header('Location: view_class.php');