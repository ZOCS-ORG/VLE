<?php 

header('Location: ../subjects/');