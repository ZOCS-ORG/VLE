<?php

define(root_path, dirname(__FILE__), true);